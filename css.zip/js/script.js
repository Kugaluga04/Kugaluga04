(function(d, s, id) {
            if (d.getElementById(id)) {
                if (window.__TOMORROW__) {
                    window.__TOMORROW__.renderWidget();
                }
                return;
            }
            const fjs = d.getElementsByTagName(s)[0];
            const js = d.createElement(s);
            js.id = id;
            js.src = "https://www.tomorrow.io/v1/widget/sdk/sdk.bundle.min.js";

            fjs.parentNode.insertBefore(js, fjs);
        })(document, 'script', 'tomorrow-sdk');

function submitMessage() {
                        alert("Thank You for your submission.");
                }

window.onload = function() {
    const d = new Date();

    let day,month,hrs,mins;

    if (d.getDate() < 10)
    {
        day = "0" + d.getDate();
    }
    else
    {
        day = d.getDate();
    }

    if ((d.getMonth() + 1) < 10)
    {
        month = "0" + (d.getMonth() + 1);
    }
    else
    {
        month = d.getMonth() + 1;
    }

    if (d.getHours() < 10)
    {
        hrs = "0" + d.getHours();
    }
    else
    {
        hrs = d.getHours();
    }

    if (d.getMinutes() < 10)
    {
        mins = "0" + d.getMinutes();
    }
    else
    {
        mins = d.getMinutes();
    }

    let date = day + "/" + month + "/" + d.getFullYear();
    let time = hrs + ":" + mins;

    document.getElementById("year").innerHTML = d.getFullYear();
    document.getElementById("dateTime").innerHTML = date + " " + time;
}